# BMI Calculator (React + Spring Boot)

A beginner-friendly BMI calculator with a React/Vite frontend and Java Spring Boot REST API.

## Requirements
- Java 17 or newer
- Node.js 20.19+ or 22.12+ recommended for current Vite releases
- Internet access for the first Maven/npm dependency downloads

## 1. Start the Spring Boot backend
Open a terminal in `backend` and run:

Windows:
```bat
mvnw.cmd spring-boot:run
```

If `mvnw.cmd` is not included or does not work, install Maven and run:
```bat
mvn spring-boot:run
```

Backend URL: `http://localhost:8080`

Test endpoint (POST):
`http://localhost:8080/api/bmi`

Example JSON body:
```json
{"heightCm":165,"weightKg":60}
```

Expected response:
```json
{"bmi":22.04,"category":"Normal range"}
```

## 2. Start the React frontend
Open a second terminal in `frontend` and run:
```bash
npm install
npm run dev
```
Open the local URL printed by Vite, usually `http://localhost:5173`.

Keep both terminals running while using the app.

## How it works
1. Enter height in centimetres and weight in kilograms.
2. React sends the values to Spring Boot using a POST request.
3. Spring Boot validates the values, calculates BMI, and returns JSON.
4. React displays the result and the general adult BMI category.

## Notes
- This is an educational demonstration, not a diagnosis or medical advice.
- Adult BMI categories are not appropriate for children and teenagers, for whom BMI is interpreted using age- and sex-specific percentiles. Do not use this app to assess a child or teen.
- No database is used; this demo does not save personal inputs.
